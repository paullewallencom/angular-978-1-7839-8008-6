## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/angularjs-essentials/9781783980086)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1783980087).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Angular-2-Essentials
Angular 2 Essentials, published by Packt
